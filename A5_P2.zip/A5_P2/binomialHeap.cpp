#include "Includes/binomialHeap.h"
#include "Includes/customErrorClass.h"
#include <climits>

static bool edgeEquals(const Edge& a, const Edge& b)
{
    return a.src == b.src && a.dest == b.dest && a.weight == b.weight;
}

binomialNode::binomialNode(Edge e)
{
    edge = e;
    degree = 0;
    parent = nullptr;
    sibling = nullptr;
    child = nullptr;
}

// ---------------------- PRIVATE FUNCTIONS ------------------------------
binomialNode* BinomialHeap::unionHeaps(binomialNode* heap1, binomialNode* heap2)
{
    if (!heap1) return heap2;
    if (!heap2) return heap1;

    binomialNode* newHead = nullptr;
    binomialNode** pos = &newHead;

    while (heap1 && heap2) {
        if (heap1->degree <= heap2->degree) {
            *pos = heap1;
            heap1 = heap1->sibling;
        } else {
            *pos = heap2;
            heap2 = heap2->sibling;
        }
        pos = &((*pos)->sibling);
    }

    *pos = heap1 ? heap1 : heap2;
    return newHead;
}


binomialNode* BinomialHeap::mergeTrees(binomialNode* tree1, binomialNode* tree2)
{
    if (tree1->edge.weight > tree2->edge.weight) swap(tree1, tree2);

    tree2->parent = tree1;
    tree2->sibling = tree1->child;
    tree1->child = tree2;
    tree1->degree++;

    return tree1;
}

void BinomialHeap::linkTrees(binomialNode*& prev, binomialNode*& curr, binomialNode*& next)
{
    if (curr->degree != next->degree || (next->sibling && next->sibling->degree == curr->degree)) {
        prev = curr;
        curr = next;
    } else {
        if (curr->edge.weight <= next->edge.weight) {
            curr->sibling = next->sibling;
            mergeTrees(curr, next);
        } else {
            if (!prev) head = next;
            else prev->sibling = next;

            mergeTrees(next, curr);
            curr = next;
        }
    }
}

binomialNode* BinomialHeap::reverseList(binomialNode* node)
{
    binomialNode* prev = nullptr;
    binomialNode* current = node;

    while (current) {
        binomialNode* next = current->sibling;
        current->sibling = prev;
        current->parent = nullptr;
        prev = current;
        current = next;
    }

    return prev;
}

binomialNode* BinomialHeap::findNode(binomialNode* root, Edge edge)
{
    if (!root) return nullptr;
    if (edgeEquals(root->edge, edge)) return root;

    binomialNode* found = findNode(root->child, edge);
    if (found) return found;

    return findNode(root->sibling, edge);
}

// ---------------- PUBLIC FUNCTIONS ------------------------------
BinomialHeap::BinomialHeap()
{
    head = nullptr;
}

void BinomialHeap::insert(Edge edge)
{
    BinomialHeap tempHeap;
    tempHeap.head = new binomialNode(edge);

    head = unionHeaps(head, tempHeap.head);

    if (!head || !head->sibling) return;

    binomialNode* prev = nullptr;
    binomialNode* curr = head;
    binomialNode* next = curr->sibling;

    while (next) {
        linkTrees(prev, curr, next);
        next = curr->sibling;
    }
}

void BinomialHeap::merge(BinomialHeap& other)
{
    head = unionHeaps(head, other.head);

    if (!head || !head->sibling) return;

    binomialNode* prev = nullptr;
    binomialNode* curr = head;
    binomialNode* next = curr->sibling;

    while (next) {
        linkTrees(prev, curr, next);
        next = curr->sibling;
    }
}

Edge BinomialHeap::findMin()
{
    if (!head) {
        throw MyException("findMin() called on empty heap");
    }

    binomialNode* minNode = head;
    binomialNode* current = head->sibling;

    while (current) {
        if (current->edge.weight < minNode->edge.weight) {
            minNode = current;
        }
        current = current->sibling;
    }

    return minNode->edge;
}

void BinomialHeap::printHeap()
{
    cout << "Binomial Heap:\n";
    binomialNode* current = head;

    while (current) {
        cout << endl << "Tree of degree " << current->degree << endl;
        printTree(current, 0);
        current = current->sibling;
    }
}

void BinomialHeap::printTree(binomialNode* node, int space)
{
    if (!node) return;

    cout << setw(space * 2) << node->edge.src << "->" << node->edge.dest << " (" << node->edge.weight << ")" << endl;

    binomialNode* child = node->child;
    while (child) {
        printTree(child, space + 3);
        child = child->sibling;
    }
}

void BinomialHeap::deleteMin()
{
    if (!head) {
        throw MyException("deleteMin() called on empty heap");
    }

    binomialNode* minNode = head;
    binomialNode* minPrev = nullptr;
    binomialNode* prev = nullptr;
    binomialNode* current = head;

    while (current) {
        if (current->edge.weight < minNode->edge.weight) {
            minNode = current;
            minPrev = prev;
        }
        prev = current;
        current = current->sibling;
    }

    if (minPrev) {
        minPrev->sibling = minNode->sibling;
    } else {
        head = minNode->sibling;
    }

    binomialNode* reversed = reverseList(minNode->child);
    head = unionHeaps(head, reversed);

    if (head) {
        binomialNode* prev2 = nullptr;
        binomialNode* curr = head;
        binomialNode* next = curr->sibling;

        while (next) {
            linkTrees(prev2, curr, next);
            next = curr->sibling;
        }
    }

    delete minNode;
}

void BinomialHeap::decreaseKey(Edge oldEdge, Edge newEdge)
{
    if (newEdge.weight > oldEdge.weight) {
        throw MyException("decreaseKey(): new weight is greater than old weight");
    }

    binomialNode* node = findNode(head, oldEdge);
    if (!node) {
        throw MyException("decreaseKey(): edge not found");
    }

    node->edge = newEdge;
    binomialNode* parent = node->parent;

    while (parent && node->edge.weight < parent->edge.weight) {
        swap(node->edge, parent->edge);
        node = parent;
        parent = node->parent;
    }
}

void BinomialHeap::deleteKey(Edge edge)
{
    binomialNode* node = findNode(head, edge);
    if (!node) {
        throw MyException("deleteKey(): edge not found");
    }

    Edge replacement = node->edge;
    replacement.weight = INT_MIN;
    decreaseKey(node->edge, replacement);
    deleteMin();
}
