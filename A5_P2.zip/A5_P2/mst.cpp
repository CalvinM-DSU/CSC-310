#include "Includes/mst.h"
#include "Includes/binaryHeap.h"       // Custom binary heap
#include "Includes/binomialHeap.h"   // Custom binomial heap

// ===== QuickUnion =====
QuickUnion::QuickUnion(int n)
{
    parent.resize(n);
    for (int i = 0; i < n; ++i) {
        parent[i] = i;
    }
}

int QuickUnion::find(int x)
{
    while (x != parent[x]) {
        x = parent[x];
    }
    return x;
}

void QuickUnion::Union(int x, int y)
{
    int rootX = find(x);
    int rootY = find(y);
    if (rootX != rootY) {
        parent[rootY] = rootX;
    }
}

// ===== UnionFind =====
UnionFind::UnionFind(int n)
{
    parent.resize(n);
    rank.resize(n);
    for (int i = 0; i < n; ++i) {
        parent[i] = i;
        rank[i] = 0;
    }
}

int UnionFind::find(int x)
{
    if (parent[x] != x) {
        parent[x] = find(parent[x]);
    }
    return parent[x];
}

void UnionFind::Union(int x, int y)
{
    int rootX = find(x);
    int rootY = find(y);
    if (rootX == rootY) return;

    if (rank[rootX] < rank[rootY]) {
        parent[rootX] = rootY;
    } else if (rank[rootX] > rank[rootY]) {
        parent[rootY] = rootX;
    } else {
        parent[rootY] = rootX;
        rank[rootX]++;
    }
}

// ===== MST =====
MST::MST(int vertices)
{
    n = vertices;
}

void MST::addEdge(int u, int v, int weight)
{
    edges.push_back({u, v, weight});
}

int MST::kruskalV1()
{
    if (edges.empty() || n <= 0) return 0;

    HEAP heap(edges.size());
    for (const auto& edge : edges) {
        heap.insertH(edge);
    }

    QuickUnion uf(n);
    int mstCost = 0;
    int edgesAdded = 0;
    int remaining = edges.size();

    while (remaining-- > 0 && edgesAdded < n - 1) {
        Edge edge = heap.peek();
        heap.deleteMin();

        int rootU = uf.find(edge.src);
        int rootV = uf.find(edge.dest);
        if (rootU != rootV) {
            uf.Union(rootU, rootV);
            mstCost += edge.weight;
            edgesAdded++;
        }
    }

    return mstCost;
}

int MST::kruskalV2()
{
    if (edges.empty() || n <= 0) return 0;

    BinomialHeap heap;
    for (const auto& edge : edges) {
        heap.insert(edge);
    }

    UnionFind uf(n);
    int mstCost = 0;
    int edgesAdded = 0;
    int remaining = edges.size();

    while (remaining-- > 0 && edgesAdded < n - 1) {
        Edge edge = heap.findMin();
        heap.deleteMin();

        int rootU = uf.find(edge.src);
        int rootV = uf.find(edge.dest);
        if (rootU != rootV) {
            uf.Union(rootU, rootV);
            mstCost += edge.weight;
            edgesAdded++;
        }
    }

    return mstCost;
}
