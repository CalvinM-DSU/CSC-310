How does the use of binomial heap improve the efficiency of Kruskal’s
algorithm compared to a binary heap?

    Binomial heaps have a faster merge operation, which makes them more efficient at combining the large datasets present


How does the use of union-find with path compression and union by size
improve the performance of Kruskal’s algorithm?

    It reduces the time complexity of DSU operations.


Explain your observations from timing both versions and discuss the time
complexity of both versions of Kruskal's algorithm.

    When tested on a small graph, the binary heap is consistently faster than the binomial implementation:
        2.414e-06 seconds
        vs
        2.915e-06 seconds
    The large graph test, however, is much more efficient with the KruskalV2:
        2.02716 seconds
        vs
        0.150536 seconds
    The time complexity of the respective merges are O(e) and O(log e), e being the number of edges