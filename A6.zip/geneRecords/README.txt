I used a quicksort for this project due to its efficiency and ability to parse larger datasets while remaining O(log n)
There are likely quicker ways to do this, but I committed to this one.

I haven't actually tested the makefile to see if it removes the sorted_samples.bin that the program creates, but it should.