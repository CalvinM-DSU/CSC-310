#include "geneBank.h"

// =================================== PUBLIC FUNCTIONS =======================================================

GENE_BANK::GENE_BANK() 
{
    this->fileSize = 0;
    this->entryByte = sizeof(Sample);
}

GENE_BANK::~GENE_BANK() 
{
    cout << "Destructing ..." << endl;
}

// helper for sort
int partition(Sample arr[], int low, int high) {
    int pivot = arr[high].speciesCode;
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (arr[j].speciesCode <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}
// I used quicksort because it can handle larger datasets efficiently
void quickSort(Sample arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void GENE_BANK::sort(Sample array[], int fileSize)
{
    quickSort(array, 0, fileSize - 1);
}

void GENE_BANK::indexSamples(Sample array[], int indexArray[]) 
{
    this->p_index(array, indexArray);
}

bool GENE_BANK::searchSample(int speciesStart, int offset, char* filename) 
{
    ifstream file(filename, ios::binary);
    if (!file) return false;

    Sample temp;
    int actualIndex = speciesStart + offset;

    file.seekg(actualIndex * sizeof(Sample), ios::beg);
    file.read((char*)&temp, sizeof(Sample));

    file.close();
    return file.good();
}

void GENE_BANK::displayResearcher(int speciesCode, int offset, char* filename) 
{
    bool checkSample = searchSample(speciesCode, offset, filename);

    if(checkSample){
        p_displayResearcher(speciesCode, offset, filename);
    } else {
        cout << "Sample record doesn't exist! Can't display researcher name." << endl;
    }
}

void GENE_BANK::updateResearcher(int speciesCode, int offset, char* newName, char* filename) 
{
    bool checkSample = this->searchSample(speciesCode, offset, filename);

    if(checkSample){
        p_updateResearcher(speciesCode, offset, newName, filename);
    } else {
        cout << "Sample record to be updated doesn't exist!" << endl;
    }
}

void GENE_BANK::deleteSample(int speciesCode, int offset, char* filename)
{
    bool checkSample = this->searchSample(speciesCode, offset, filename);

    if(checkSample){
        p_deleteSample(speciesCode, offset, filename);
    } else {
        cout << "Sample record to be deleted doesn't exist!" << endl;
    }
}

void GENE_BANK::printSampleRange(int speciesCode, int startIndex, int endIndex, char* filename) 
{
    if(startIndex >= endIndex)
        throw MyException("ERROR: start index is larger than end index!");
    else
        this->p_printRange(speciesCode, startIndex, endIndex, filename);
}

// =================================== PRIVATE FUNCTIONS =======================================================

void GENE_BANK::p_index(Sample array[], int indexArray[]) 
{
    for (int i = 0; i < 5; i++)
        indexArray[i] = -1;

    for (int i = 0; i < fileSize; i++) {
        int code = array[i].speciesCode;
        if (indexArray[code] == -1) {
            indexArray[code] = i;
        }
    }
}

void GENE_BANK::p_displayResearcher(int speciesStart, int offset, char* filename) 
{
    ifstream file(filename, ios::binary);

    Sample temp;
    int actualIndex = speciesStart + offset;

    file.seekg(actualIndex * sizeof(Sample), ios::beg);
    file.read((char*)&temp, sizeof(Sample));

    cout << "Researcher: " << temp.researcher << endl;

    file.close();
}

void GENE_BANK::p_updateResearcher(int speciesStart, int offset, char* newName, char* filename) 
{
    fstream file(filename, ios::in | ios::out | ios::binary);

    Sample temp;
    int actualIndex = speciesStart + offset;

    file.seekg(actualIndex * sizeof(Sample), ios::beg);
    file.read((char*)&temp, sizeof(Sample));

    strncpy(temp.researcher, newName, MAX_RESEARCHER_NAME);

    file.seekp(actualIndex * sizeof(Sample), ios::beg);
    file.write((char*)&temp, sizeof(Sample));

    file.close();
}

void GENE_BANK::p_deleteSample(int speciesStart, int offset, char* filename) 
{
    fstream file(filename, ios::in | ios::out | ios::binary);

    Sample temp;
    int actualIndex = speciesStart + offset;

    file.seekg(actualIndex * sizeof(Sample), ios::beg);
    file.read((char*)&temp, sizeof(Sample));

    temp.speciesCode = -1;

    file.seekp(actualIndex * sizeof(Sample), ios::beg);
    file.write((char*)&temp, sizeof(Sample));

    file.close();
}

void GENE_BANK::p_printRange(int speciesStart, int startIndex, int endIndex, char* filename) 
{
    ifstream file(filename, ios::binary);

    Sample temp;

    for (int i = startIndex; i <= endIndex; i++) {
        int actualIndex = speciesStart + i;

        file.seekg(actualIndex * sizeof(Sample), ios::beg);
        file.read((char*)&temp, sizeof(Sample));

        cout << "ID: " << temp.sampleID
             << " | Purity: " << temp.purityScore
             << " | Researcher: " << temp.researcher
             << endl;
    }

    file.close();
}